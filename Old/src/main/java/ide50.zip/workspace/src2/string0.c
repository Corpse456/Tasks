#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    system("clear");
    string s;
    do
       s = get_string();
    while (s == NULL);
    
     for (int i = 0; i < strlen(s); i++)
        {
            printf("%c\n", s[i]);
        }
}
