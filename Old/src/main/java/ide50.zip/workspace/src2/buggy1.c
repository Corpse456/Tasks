#include <stdio.h>

int main(void)
{
    string s = get_string();
    printf("hello, %s\n", s);
}
