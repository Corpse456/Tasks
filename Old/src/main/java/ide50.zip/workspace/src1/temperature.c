#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int choise;                 
    do
    {
        printf("Choise:\n 0. Celsius to Fahrenheit\n 1. Fahrenheit to Celsius\n ");
        choise = get_int();
    }
    while (choise<0 || choise>1);
   
    printf("Input the temperature: ");
    float temp = get_float();
    
    if (choise == 1)
    {
        float cels = 5.0 / 9.0 * (temp - 32.0);
        printf("Temperature in Celsius: %.1f\n", cels);
    }
    else
    {
        float fah = temp * 9.0 / 5.0 + 32.0;
        printf("Temperature in Fahrenheit: %.1f\n", fah);
    }
    return 0;
}
