//поиск значения в массиве данных
#include <cs50.h>
#include <stdio.h>

#define SIZE 200  //размер массива

bool search(int, int[], int, int);  //поиск 

int main(void)
{
    int array[SIZE]={0};
    for (int i = 0; i < SIZE; i++)
    {
        array[i] = rand()%SIZE;   //заполнение массива случайными числами
        printf("%i ", array[i]);
    }
    
    int needle;
    do
    {
        printf("\nNeedle is... (Max number is %i) ",SIZE);
        needle = get_int();
    }
    while (needle < 0 || needle > SIZE);
    
    if (search(needle,array,0,SIZE-1))
    {
        printf("Needle found!!!\n");
    }
    else
    {
        printf("Sorry, try again...\n");
    }
return 0;
}

bool search(int n, int array[], int lower, int upper)
{   
    while (lower <= upper)
    {
    if (n == array[lower]) return true;
    else lower++;
    }
    return false;
}
