/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in values of n values, else false.
 */
bool search(int value, int values[], int n)
{
    int start = 0;
    while (start < n)
    {
        int middle = (n + start) / 2;
        
        if (values[middle] == value)
        {
            return true;
        }
        else if (values[middle] > value)
        {
            n = middle - 1;    
        }
        else if (values[middle] < value)
        {
            start = middle + 1;
        }
        else return false;
    }
    return false;
}

/**
 * Sorts values of n values.
 */
void sort(int values[], int n)
{
    int max = n;
    for (int i = n; i >= 0; i--)
    {
        if (values[max] < values[i])
        {
            max = i;
        }
    }
    
    if (max != n)
    {
        int change = values[max];
        values[max] = values[n];
        values[n] = change;
    }
    
    if (n!=0) sort(values,n-1);
}