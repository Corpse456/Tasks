

#include <cs50.h>
#include <stdio.h>

#define SIZE 8

bool search(int n, int array[], int lower, int upper)
{
    printf("upper %i\n",upper);
    printf("array[upper] %i\n",array[upper]);
    printf("lower %i\n",lower);
    printf("array[lower] %i\n",array[lower]);
    // if n is not in array
    if (upper < lower)
    {
        // return false
        return false;
    }

    // define middle
    int mid = (lower + upper) / 2;
    printf("mid %i\n",mid);
    printf("array[mid] %i\n",array[mid]);

    // if n is left of middle
    if(n < array[mid])
    {
        // search left half
        return search(n, array, lower, mid - 1);
    }

    // if n is right of middle
    else if(n > array[mid])
    {
        // search right half
        return search(n, array, mid + 1, upper);
    }

    // if n is at middle
    else
    {
        return true;
    }
}

int main(void)
{
    int numbers[SIZE] = { 4, 8, 15, 16, 23, 42, 50, 108 };
    printf("> ");
    int n = GetInt();
    if (search(n, numbers, 0, SIZE - 1))
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
}