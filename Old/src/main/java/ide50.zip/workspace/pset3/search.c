//поиск значения в массиве данных
#include <cs50.h>
#include <stdio.h>

#define SIZE 10  //размер массива

bool search(int, int[], int, int);  //поиск 

int main(void)
{
    int array[SIZE]={1,2,3,9,15,19,21,37,56,99};
    for (int i = 0; i < SIZE; i++)
    {
        printf(" %i",array[i]);
        //array[i] = i+1;   //заполнение массива числами
    }
    
    int needle;
    do
    {
        printf("\nNeedle is... (Max number is %i) ",SIZE*10);
        needle = get_int();
    }
    while (needle < 0 || needle > SIZE*10);
    
    if (search(needle,array,0,SIZE-1))
    {
        printf("Needle found!!!\n");
    }
    else
    {
        printf("Sorry, try again...\n");
    }
return 0;
}

bool search (int needle, int array[], int start, int size)
{
    if (start > size)
    {
        return false;
    }
    
    int middle = (size + start) / 2;
  
    if (array[middle] == needle)
    {
        return true;
    }
    else if (array[middle] > needle) 
    {
        return search (needle,array,start,middle - 1);
    }
    else if (array[middle] < needle) 
    {
        return search (needle,array,middle + 1,size);
    }
    else return false;
}
