#include <cs50.h>
#include <stdio.h>
#include <time.h>

long sigma(int);
void swap(int,int);

int main(void)
{
    int n;
    do
    {
        printf("Positive integer please: ");
        n = get_int();
    }
    while (n < 1);
    
    float start_time =  clock();
    long answer = sigma(n);
    printf("Spent time: %.2f seconds\n",(clock()-start_time)/1000000);

    printf("%li\n", answer);
    int a = 5, b = 6;
    swap(a,b);
    printf("a: %i/ b: %i\n",a,b);
}

long sigma(int m)
{
    long sum = 0;
    for (int i = 1; i <= m; i++)
    {
        sum += i;
    }
    return sum;
}

/*long sigma(int m)
{
    if (m <= 0)
    {
        return 0;
    }
    else
    {
        return (m + sigma(m - 1));
    }
}*/

void swap(int a,int b)
{
    a = a ^ b;
    printf("a: %i/ b: %i\n",a,b);
    b = a ^ b;
    printf("a: %i/ b: %i\n",a,b);
    a = a ^ b;
    printf("a: %i/ b: %i\n",a,b);
}