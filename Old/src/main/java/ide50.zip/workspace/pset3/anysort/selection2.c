#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define size 10000

int main(void)
{
    int array[size]={0};
    for (int i = 0; i< size; i++)
    {
        array[i] = rand()%size;
        printf("%i ",array[i]);
    }
    
    printf("\n");
    
    float start_time =  clock();
    
    for (int j = 0; j < size-1; j++)
    {
        int min = j;
        for (int i = min; i < size; i++)
        {
            if (array[min] > array[i])
            {
                min = i;
            }
        }
        if (min != 0)
        {
            int change = array[min];
            array[min] = array[j];
            array[j] = change;
        }
    }
    
    printf("\n");
    
    for (int i = 0; i< size; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    float end_time =  clock();
    printf("Spent time: %.2f seconds\n",(end_time-start_time)/1000000);
    return 0;
}