//сортировка вставкой
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define size 30000  //размер массива

void sort(int[]);  //сортировка

int main(void)
{
    int array[size];
    srand(time(NULL));
    for (int i = 0; i < size; i++)
    {
        array[i] = rand()%(size + 1);   //заполнение массива случайными числами
        printf("%i ",array[i]);
    }
    
    printf("\n");
    
    double start_time =  clock(); 
    
    sort(array);
    
    printf("\n");
    
    for (int i = 0; i< size; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    
    printf("Spent time: %.10f seconds\n",(clock()-start_time)/1000000);
    
    start_time =  clock();
    sort(array);
    printf("Spent time 2: %.10f seconds\n",(clock()-start_time)/1000000);
    
    return 0;
}

void sort(int array[])
{
    for (int i = 1; i < size; i++)
    {
        if (array[i] < array[i-1])
            {
                int buff = array[i], j;
                for (j = i-1; buff < array[j] && j >= 0 ; j--)
                {
                    array[j+1] = array[j];
                }
                array[j+1] = buff;
            }
    }
}
