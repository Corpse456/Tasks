//сортировка слиянием
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define SIZE 30000  //размер массива

int temp[SIZE] = {0};

void sort(int[],int,int);  //сортировка
void merge(int[],int,int,int,int); //слияние

int main(void)
{
    int array[SIZE];
    srand(time(NULL));
    for (int i = 0; i < SIZE; i++)
    {
        array[i] = rand()%(SIZE+1);   //заполнение массива случайными числами
        printf("%i ",array[i]);
    }
    printf("\n");
    
    float start_time =  clock(); 
    
    sort(array,0,SIZE-1);
    
    printf("\n");
    
    for (int i = 0; i < SIZE; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    printf("Spent time: %.10f seconds\n",(clock()-start_time)/1000000);
    
    start_time =  clock(); 
    sort(array,0,SIZE-1);
    printf("Spent time: %.10f seconds\n",(clock()-start_time)/1000000);
    
    return 0;
}

void sort(int array[],int start, int end)
{
    if (end > start)
    {
        int mid = (start + end) / 2;
        
        //левая половина
        sort(array,start,mid);  
        
        //правая половина
        sort(array,mid+1,end);  
        
        //объединение двух половин
        merge(array,start,mid,mid+1,end);  
    }
}

void merge(int array[], int start1, int end1, int start2, int end2) 
{
    int index = start1;
    int length = end2 - start1;
    
    //пока не закончатся элементы в одном из подмассивов
    while (start1 <= end1 && start2 <= end2)
    {
        // Сравнение чисел в начале подмассивов
        if (array[start1] <= array[start2])
        {
            // Добавление наименьшего к объединенному массиву
            temp[index] = array[start1];
            index++;
            start1++;
        }
        else
        {
            // Добавление наименьшего к объединенному массиву
            temp[index] = array[start2];
            index++;
            start2++;
        } 
    }
    
    //если остались элементы в первом подмассиве
    while(start1 <= end1)
    {
        temp[index] = array[start1];
        start1++;
        index++;
    }
    
    //если остались элементы во втором подмассиве
    while(start2 <= end2)
    {
        temp[index] = array[start2];
        start2++;
        index++;
    }
    // заполнить отсортированными элементами изначальный массив
    for (int i = end2, j = 0; j <= length; i--, j++)
    {
        array[i] = temp[i];
    }
}