#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define size 30000

void Change(int[]);

int main(void)
{
    int array[size]={0};
    for (int i = 0; i < size; i++)
    {
        array[i] = rand()%size;
        printf("%i ",array[i]);
    }
    
    printf("\n");
    
    float start_time =  clock();
    
    Change(array);
    
    printf("\n");
    
    for (int i = 0; i< size; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    float end_time =  clock();
    printf("Spent time: %.2f seconds\n",(end_time-start_time)/1000000);
    return 0;
}

void Change(int array[])
{
    int counter;    //счётчик необходимости сортировки
    do
    {
        counter = 0;
        for (int i = 0; i < size-1; i++)
        {
            if (array[i] > array[i+1])
            {
                int chage = array[i];   //смен мест двух соседних элементов
                array[i] = array[i+1];
                array[i+1] = chage;
                counter++;
            }
        }
    }
    while (counter > 0);
}