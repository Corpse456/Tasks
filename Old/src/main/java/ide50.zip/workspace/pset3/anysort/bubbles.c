#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define size 30000

void Change(int[]);
bool Sort(int[]);

int main(void)
{
    int array[size]={0};
    srand(time(NULL));
    for (int i = 0; i < size; i++)
    {
        array[i] = rand()%size;
        printf("%i ",array[i]);
    }
    
    printf("\n");
    
    float start_time =  clock();
    
    Change(array);
    
    printf("\n");
    
    for (int i = 0; i< size; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    float end_time =  clock();
    printf("Spent time: %.2f seconds\n",(end_time-start_time)/1000000);
    
    start_time =  clock();
    Change(array);
    printf("\n");
    end_time =  clock();
    printf("Spent time 2: %.2f seconds\n",(end_time-start_time)/1000000);
    
    return 0;
}

void Change(int array[])
{
    for (int i = 0; i < size-1; i++)
    {
        if (array[i] > array[i+1])
        {
            int chage = array[i];
            array[i] = array[i+1];
            array[i+1] = chage;
        }
    }
    if (!Sort(array)) Change(array);
}

bool Sort(int array[])
{
    for (int i = 0; i< size-1; i++)
    {
        if (array[i] > array[i+1])
        return false;
    }
    return true;
}