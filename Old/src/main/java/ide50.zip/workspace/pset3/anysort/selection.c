#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h> 

#define SIZE 30000
void Change(int[],int);

int main(void)
{
    int array[SIZE]={0};
    srand(time(NULL));
    for (int i = 0; i < SIZE; i++)
    {
        array[i] = rand()%(SIZE+1);
        printf("%i ",array[i]);
    }
    
    printf("\n");
    
    float start_time = clock();
    
    Change(array,0);
    
    printf("\n");
    
    for (int i = 0; i< SIZE; i++)
    {
        printf("%i ",array[i]);
    }
    printf("\n");
    
    printf("Spent time: %.2f seconds\n",(clock()-start_time)/1000000);
    
    start_time =  clock();
    Change(array,0);
    
    printf("Spent time 2: %.2f seconds\n",(clock()-start_time)/1000000);
    
    return 0;
}

void Change(int array[],int n)
{
    int min = n;
    for (int i = n; i < SIZE; i++)
    {
        if (array[min] > array[i])
        {
            min = i;
        }
    }
    
    if (min != n)
    {
        int change = array[min];
        array[min] = array[n];
        array[n] = change;
    }
    
    if (n!=SIZE) Change(array,n+1);
}
