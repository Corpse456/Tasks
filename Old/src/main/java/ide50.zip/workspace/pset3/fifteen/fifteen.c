/**
 * fifteen.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Implements Game of Fifteen (generalized to d x d).
 *
 * Usage: fifteen d
 *
 * whereby the board's dimensions are to be d x d,
 * where d must be in [DIM_MIN,DIM_MAX]
 *
 * Note that usleep is obsolete, but it offers more granularity than
 * sleep and is simpler to use than nanosleep; `man usleep` for more.
 */
 
#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h> 
#include <string.h>

// constants
#define DIM_MIN 3
#define DIM_MAX 9

// board
int board[DIM_MAX][DIM_MAX];
int board2[DIM_MAX*DIM_MAX];

// dimensions
int d;

// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
bool won(void);
void change(int,int,int,int);
void godmode(void);
void step(int);
void swap (void);

int main(int argc, string argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: fifteen d\n");
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    if (d < DIM_MIN || d > DIM_MAX)
    {
        printf("Board must be between %i x %i and %i x %i, inclusive.\n",
            DIM_MIN, DIM_MIN, DIM_MAX, DIM_MAX);
        return 2;
    }

    // open log
    FILE* file = fopen("log.txt", "w");
    if (file == NULL)
    {
        return 3;
    }

    // greet user with instructions
    greet();

    // initialize the board
    init();

    // accept moves until game is won
    while (true)
    {
        // clear the screen
        clear();

        // draw the current state of the board
        draw();

        // log the current state of the board (for testing)
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
                fprintf(file, "%i", board[i][j]);
                if (j < d - 1)
                {
                    fprintf(file, "|");
                }
            }
            fprintf(file, "\n");
        }
        fflush(file);

        // check for win
        if (won())
        {
            printf("You won!!!\n");
            break;
        }

        // prompt for move
        printf("\033[0mTile to move: ");
        string tile = GetString();

        // quit if user inputs 0 (for testing)
        if (!strcmp(tile,"0"))
        {
            printf("Exiting...\n");
            break;
        }
        
        if (!strcmp(tile,"GOD"))
        {
            godmode();
            break;
        }

        // log move (for testing)
        fprintf(file, "%i\n", atoi(tile));
        fflush(file);

        // move if possible, else report illegality
        if (!move(atoi(tile)))
        {
            printf("\nIllegal move.\n");
            usleep(500000);
        }

        // sleep thread for animation's sake
        usleep(200000);
    }
    
    // close log
    fclose(file);

    // success
    return 0;
}

/**
 * Clears screen using ANSI escape sequences.
 */
void clear(void)
{
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/**
 * Greets player.
 */
void greet(void)
{
    clear();
    printf("\t\t\tWELCOME TO GAME OF FIFTEEN!\n");
    printf("If you want to move tile, please input the number written on it\n");
    printf("Press enter...\n");
    GetString();
}

/**
 * Initializes the game's board with tiles numbered 1 through d*d - 1
 * (i.e., fills 2D array with values but does not actually print them).  
 */
void init(void)
{
    int number = d*d - 1;
    board2[number] = 0;
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            board[i][j] = number;
            board2[number-1] = number;
            number--;
        }
    }
    if ((d*d)%2 == 0)
    {
        int change = board[d-1][d-3];
        board[d-1][d-3] = board[d-1][d-2];
        board[d-1][d-2] = change;
    }
    swap();
}

void swap(void)
{
    srand(time(NULL));
    for (int i = 0; i < 1000; i++)
    {
        for (int j = 0; j < 1000; j++)
        {
            move(board[rand()%d][rand()%d]);
        }
    }
}

/**
 * Prints the board in its current state.
 */
void draw(void)
{
    int z = 0;
    for (int i = 0; i < d; i++)
    {
        for (int k = 0; k <= d-1; k++)
        {
            printf("\033[40;1m");
            printf("-----");
        }
        printf("-\n");
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] == 0)
            {
                printf("\033[40;1m|    ");
            }
            else
            {
                printf("\033[40;1m|");
                printf("\033[0m");
                if (board[i][j] == board2[z])
                {
                    printf("\033[32;1m%3d ",board[i][j]);
                    printf("\033[0m");
                }
                else
                {
                    printf("%3d ",board[i][j]);
                }
            }
            z++;
        }
        printf("\033[40;1m|\n");
    }
    for (int k = 0; k <= d-1; k++)
    {
        printf("-----");
    }
    printf("-\n");
    printf("\033[0m");
}

/**
 * If tile borders empty space, moves tile and returns true, else
 * returns false. 
 */
bool move(int tile)
{
    //printf("in move");
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] == tile)
            {
                if ((board[i+1][j] == 0) && (i+1 != d))
                {
                    change(i,j,i+1,j);
                    return true;
                }
                else if ((board[i-1][j] == 0) && (i-1 != -1)) 
                {
                    change(i,j,i-1,j);
                    return true;
                }
                else if ((board[i][j+1] == 0) && (j+1 != d))
                {
                    change(i,j,i,j+1);
                    return true;
                }
                else if ((board[i][j-1] == 0) && (j-1 != -1))
                {
                    change(i,j,i,j-1);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
    return false;
}

/**
 * Returns true if game is won (i.e., board is in winning configuration), 
 * else false.
 */
bool won(void)
{
    int min = 0;
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] == board2[min])
            {
                min++;
            }
            else return false;
        }
    }
    return true;
}

void change(int i, int j, int k, int m)
{
    int change = board[i][j];
    board[i][j] = board[k][m];
    board[k][m] = change;
}

void godmode (void)
{
    int min = 0, k = 0, m = 0,counter=0;
    while(!won())
    {
        /*min = 0;
        k = 0;
        m = 0;*/
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
               if (board[i][j] == board2[min])
               {
                   if (i == k && j == m)
                   {
                       /*printf("YES! Min: %i/k: %i/m: %i/board2[Min]: %i/i: %i/j: %i/counter: %i ",min,k,m,board2[min],i,j,counter);
                       usleep(200000);*/
                       min++;
                       m++;
                       if (m == d)
                       {
                           k++;
                           m = 0;
                       }
                       if (k == d-2 || k == d-1)
                       {
                           counter++;
                       }
                       //printf("\ncounter: %i\n",counter);
                       if (k == d-2 && counter%2 != 0 && m != d-1)
                       {
                           /*printf("Here\n");
                           usleep(900000);*/
                           k = d-1;
                           m = m%d;
                           min += d;
                           continue;
                       }
                       if (k == d-1 && counter%2 == 0)
                       {
                           /*printf("Not here\n");
                           usleep(9000000);*/
                       /*printf("NO! Min: %i/k: %i/m: %i/board2[Min]: %i/i: %i/j: %i ",min,k,m,board2[min],i,j);
                       usleep(200000);*/
                           k = d-2;
                           m--;
                           min = min - 1 - d;
                           continue;
                       }
                       continue;
                   }
                   /*else
                   {*/
                       for (int x = 0; x < d; x++)
                       {
                           for (int y = 0; y < d; y++)
                           {
                               if (board[x][y] == 0)
                               {
                                   /*printf("Min: %i/k: %i/m: %i/board2[Min]: %i/i: %i/j: %i ",min,k,m,board2[min],i,j);
                                   usleep(50000);*/
                                   if (i == k && j > m)
                                   {
                                       if (x > i && (y == j || y > j))
                                       {
                                           if (k == d-2 && i == k && j == m+1 && y == j)
                                           {
                                               step(board[x][y+1]);
                                           }
                                           else if (k == d-2 && i == k && j == m+1 && y > j)
                                           {
                                               /*printf("Hello");
                                               usleep(900000);*/
                                               step(board[x-1][y]);
                                               x -= 1;
                                               //printf("1");
                                               //usleep(900000);
                                               step(board[x][y-1]);
                                               y -= 1;
                                               //printf("2");
                                               //usleep(900000);
                                               step(board[x][y-1]);
                                               y -= 1;
                                               //printf("3");
                                               //usleep(900000);
                                               step(board[x+1][y]);
                                               x += 1;
                                               //printf("4");
                                               //usleep(900000);
                                               step(board[x][y+1]);
                                               y += 1;
                                               //printf("5");
                                               //usleep(900000);
                                               step(board[x-1][y]);
                                               x -= 1;
                                               //printf("6");
                                               //usleep(900000);
                                               step(board[x][y+1]);
                                               y += 1;
                                               //printf("7");
                                               //usleep(900000);
                                               step(board[x+1][y]);
                                               x += 1;
                                               //printf("8");
                                               //usleep(900000);
                                               step(board[x][y-1]);
                                               y -= 1;
                                               //printf("9");
                                               //usleep(900000);
                                               step(board[x][y-1]);
                                               y -= 1;
                                               //printf("10");
                                               //usleep(900000);
                                               step(board[x-1][y]);
                                               x -= 1;
                                               //printf("11");
                                               //usleep(900000);
                                               step(board[x][y+1]);
                                           }
                                           else
                                           {
                                               step(board[x][y-1]);
                                           }
                                       }
                                       else if (x > i && y < j)
                                       {
                                           /*printf("FUCK");
                                           usleep(500000);*/
                                           if (y == j-1)
                                           {
                                               step(board[x-1][y]);
                                           }
                                           step(board[x][y+1]);
                                       }
                                       else if (x == i && y < j)
                                       {
                                           /*printf("need");
                                           usleep(500000);*/
                                           step(board[x][y+1]);
                                       }
                                       else if (x == i && y > j)
                                       {
                                           if (x == d-1)
                                           {
                                               step(board[x-1][y]);
                                           }
                                           else
                                           {
                                               step(board[x+1][y]);
                                           }
                                       }
                                       else if (x < i && y >= j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x < i && y < j)
                                       {
                                           step(board[x+1][y]);
                                       }
                                   }
                                   else if (i > k && j == m)
                                   {
                                       if (x < i && y == j)
                                       {
                                           step(board[x+1][y]);
                                       }
                                       else if (x < i && y > j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x < i && y < j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                       else if (x > i && y == j)
                                       {
                                           /*printf("FUCK");
                                            usleep(500000);*/
                                           if (x == k+2 && y == d-1)
                                           {
                                               /*printf("FUCK2");
                                               usleep(900000);*/
                                               step(board[x-1][y]);
                                               x -= 1;
                                               step(board[x-1][y]);
                                               x -= 1;
                                               step(board[x][y-1]);
                                               y -= 1;
                                               step(board[x+1][y]);
                                               x += 1;
                                               step(board[x][y+1]);
                                               y += 1;
                                               step(board[x+1][y]);
                                               x += 1;
                                               step(board[x][y-1]);
                                               y -= 1;
                                               step(board[x-1][y]);
                                               x -= 1;
                                               step(board[x-1][y]);
                                               x -= 1;
                                               step(board[x][y+1]);
                                               y += 1;
                                               step(board[x+1][y]);
                                           }
                                           if (y == d-1)
                                           {
                                               step(board[x][y-1]);
                                           }
                                           else
                                           {
                                               step(board[x][y+1]);
                                           }
                                       }
                                       else if (x >= i && (y > j || y < j))
                                       {
                                           if (i == k+1 && j == m && j == y+1)
                                           {
                                               /*printf("Inside");
                                               usleep(500000);
                                               printf("Min: %i/k: %i/m: %i/board2[Min]: %i/i: %i/j: %i ",min,k,m,board2[min],i,j);
                                               usleep(200000);*/
                                               if (x == i)
                                               {
                                                   step(board[x+1][y]);
                                               }
                                               if (x > i)
                                               {
                                                   step(board[x][y+1]);
                                               }
                                           }
                                           step(board[x-1][y]);
                                       }
                                   }
                                   else if (i > k && j < m)
                                   {
                                       if (x > i && y > j)
                                       {
                                           step(board[x-1][y]);
                                       }
                                       else if (x == i && y > j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x == i && y < j)
                                       {
                                           /*printf("d: %i/x: %i ",d,x);
                                           usleep(500000);*/
                                           if (x == d-1)
                                           {
                                               step(board[x-1][y]);
                                           }
                                           else
                                           {
                                               step(board[x+1][y]);
                                           }
                                       }
                                       else if ((x > i || x < i) && y <= j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                       else if (x < i && y > j)
                                       {
                                           step(board[x+1][y]);
                                       }
                                       else if (x < i && y <= j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                   }
                                   else if (i > k && j > m)
                                   {
                                       if (x >= i && y > j)
                                       {
                                           step(board[x-1][y]);
                                       }
                                       if (x == i && y < j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                       else if (x < i && y > j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x < i && y < j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                       else if (x < i && y == j)
                                       {
                                           step(board[x+1][y]);
                                       }
                                       else if (x > i && y == j)
                                       {
                                           if (y == d-1)
                                           {
                                               step(board[x][y-1]);
                                           }
                                           else
                                           {
                                               step(board[x][y+1]);
                                           }
                                       }
                                       else if (x > i && y < j)
                                       {
                                           step(board[x-1][y]);
                                       }
                                   }
                                   else if (i < k && j > m)
                                   {
                                       if (x == i && y > j)
                                       {
                                           if (i == k+1 && j == m+1 && y == j+1)
                                           {
                                               /*printf("Hello");
                                               usleep(900000);*/
                                               step(board[x][y-1]);
                                               y -= 1;
                                               step(board[x][y-1]);
                                               y -= 1;
                                               step(board[x+1][y]);
                                               x += 1;
                                               step(board[x][y+1]);
                                               y += 1;
                                               step(board[x][x-1]);
                                               x -= 1;
                                               step(board[x][y+1]);
                                               y += 1;
                                               step(board[x][x+1]);
                                               x += 1;
                                               step(board[y-1][y]);
                                               y -= 1;
                                               step(board[y-1][y]);
                                               y -= 1;
                                               step(board[x][x-1]);
                                               x -= 1;
                                               step(board[y+1][y]);
                                           }
                                           step(board[x+1][y]);
                                       }
                                       else if (x == i && y < j)
                                       {
                                           step(board[x][y+1]);
                                       }
                                       else if (x > i && y >= j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x > i && y < j)
                                       {
                                           step(board[x-1][y]);
                                       }
                                   }
                                   else if (i < k && j == m)
                                   {
                                       if (x == i && y > j)
                                       {
                                           step(board[x+1][y]);
                                       }
                                       else if (x > i && y > j)
                                       {
                                           step(board[x][y-1]);
                                       }
                                       else if (x > i && y == j)
                                       {
                                           step(board[x-1][y]);
                                       }
                                   }
                               }
                           }
                       }
                   /*}*/
               }
            }
        }
    }
    printf("\nthank you for using God-mode ;-)\n");
}

void step(int sdvig)
{
    int sleep = 1500000;
    move(sdvig);
    sleep /= d*d/1.5;
    usleep(sleep);
    clear();
    draw();
}