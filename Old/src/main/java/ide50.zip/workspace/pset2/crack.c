#define _XOPEN_SOURCE   //DES cypher
#include <crypt.h>      //
#include <cs50.h>       //GetString, booleans, and string datatype
#include <stdio.h>      //printf
#include <string.h>     //strlen
#include <unistd.h>     //DES cypher
#include <time.h> 

int main (int argc, string argv[])
{
    if (argc!=2)    //проверка наличия одного аргумента
    {
        printf("Usage: ./crypt <hash>\n");
        return 1;
    }
    if (strlen(argv[1])!=13)    //проверка верной длины хеша для DES
    {
        printf("Next time input correct hash,please...\n");
        return 1;
    }
    char salt[2];
    salt[0]=argv[1][0];
    salt[1]=argv[1][1];
    
    unsigned int start_time =  clock();
    
    float perc = 0.00000000;
    
    char pass[5] = { 0 };
    for (int i = '0'; i <= 'z'; i++)
    {
        pass[0] = (char) i;

        if ((strcmp(argv[1], crypt(pass,salt))) == 0)
        {
            printf("Password is %s!\n",pass);
            unsigned int end_time =  clock();
            printf("Spent time: %i seconds\n",(end_time-start_time)/1000000);
            return 1;
        }
        if (i == '9') i = 'A';
        if (i == 'Z') i = 'a';
        
        for (int j = '0'; j <= 'z'; j++)
        {
            pass[1] = (char) j;
            if ((strcmp(argv[1], crypt(pass,salt))) == 0)
            {
                printf("Password is %s!\n",pass);
                unsigned int end_time =  clock();
                printf("Spent time: %i seconds\n",(end_time-start_time)/1000000);
                //printf("%s\n",crypt("1234","ok"));
                return 1;
            }
            if (j == '9') j = 'A';
            if (j == 'Z') j = 'a';
            
            for (int k = '0'; k <= 'z'; k++)
            {
                pass[2] = (char) k;
                if ((strcmp(argv[1], crypt(pass,salt))) == 0)
                {
                    printf("Password is %s!\n",pass);
                    unsigned int end_time =  clock();
                    printf("Spent time: %i seconds\n",(end_time-start_time)/1000000);
                    return 1;
                }
                if (k == '9') k = 'A';
                if (k == 'Z') k = 'a';
                
                for (int l = '0'; l <= 'z'; l++)
                {
                    pass[3] = (char) l;
                    if ((strcmp(argv[1], crypt(pass,salt))) == 0)
                    {
                        printf("Password is %s!\n",pass);
                        unsigned int end_time =  clock();
                        printf("Spent time: %i seconds\n",(end_time-start_time)/1000000);
                        return 1;
                    }
                    if (l == '9') l = 'A';
                    if (l == 'Z') l = 'a';
                    //printf("%s\n",pass);
                    pass[4] = '\0';
                }
                pass[3] = '\0';
            }
            perc = perc + 0.02601457;
            system("clear");
            printf("Percent complete: %.0f\n",perc);
            pass[2] = '\0';
        }
        pass[1] = '\0';
    }
    unsigned int end_time =  clock();
    printf("Spent time: %i seconds\n",(end_time-start_time)/1000000);
    return 0;
}