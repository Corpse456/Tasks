//Кодирует и раскодирует кодом Виженера
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

string Key(string);  //обработка ключа
string Choise(int); //выбор между шифровкой/расшифровкой
char Cipher(char,char,int); //шифрование/расшифровка

int main(int argc, string argv[])
{
    if (argc!=2)    //проверка наличия одного аргумента
    {
        printf("Usage: ./vigenere <key>\n");
        return 1;
    }
    
    string key =  Key (argv[1]); //верен ли ключ
    if (key == 0) return 1;
    //system("clear");    
    
    int choise;                  //выбор между шифровкой/расшифровкой
    do
    {
        printf("Input:\n 0. To crypt\n 1. To uncrypt\n ");
        choise = get_int();
    }
    while (choise<0 || choise>1);
    string text = Choise(choise); 
    
    int lenght = strlen(key);        
    for (int i=0,j=0;i<strlen(text);i++,j++)
        {
            j=j%lenght;
            if (isalpha(text[i])) //отбор букв
            {
                text[i]=Cipher(text[i],key[j],choise);
            }
            else j--; //защита от сдвига ключа на небуквенных символах
        }
    if (choise==0) printf("\nciphertext: %s\n",text);
    else printf("\nplaintext: %s\n",text);
    return 0;
}

string Key(string key)
{
    for (int i=0;i<strlen(key);i++) //проверка ключа на отсутсвия символов, не являющихся алфавитными
    {
        if (!isalpha(key[i]))
        {
            printf("Using only english alphabet\n");
            return 0;
        }
        else key[i]=toupper(key[i]); //ключ превращается в строчные
    }
    return key;
}

char Cipher(char letCh,char letKey,int choise)
{
    if (isupper(letCh))                 //строчные
    {
        if (choise==0) letCh=(letCh+letKey-130)%26+65; //шифрование 
        else      letCh=(26+letCh-letKey)%26+65;  //дешифрование
    }
    else                                //прописные
    {
        if (choise==0) letCh=(letCh+letKey-162)%26+97; //шифрование 
        else letCh=(letCh-letKey-6)%26+97;       //дешифрование 
    }
    return letCh;
}

string Choise(int choise)
{
    string prepText;
    if (choise==0)   //шифрование
    {
        printf("plaintext: ");
        prepText = get_string();
    }
    else        //дешифровка
    {
        printf("ciphertext: ");
        prepText = get_string();
    }
    return prepText;
}