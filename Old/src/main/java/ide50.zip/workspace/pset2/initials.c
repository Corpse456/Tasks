//выдаёт инициалы
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    system("clear");
    string name = get_string();
    if (name != NULL)
    {
        if (!isblank(name[0]))  //проверка первого символа
            printf("%c", toupper(name[0]));  
               
        for(int l=strlen(name),i=0;i<l-1;i++) //поиск начала слов
            if (isblank(name[i])&&!isblank(name[i+1])&&i+1!=l)
                printf("%c", toupper(name[i+1])); 
        printf("\n");
    }
    return 0;
}