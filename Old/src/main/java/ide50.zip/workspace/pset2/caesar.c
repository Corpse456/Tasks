//Шифрует и расшифровывает кодом Цезяря
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    if (argc != 2)    
    {
        printf("Usage: ./caesar <key>\n");
        return 1;
    }
    
    int key = atoi (argv[1]);
    if (!(key>0 && key<27))
    {
        printf("Key value from 1 to 26\n");
        return 1;
    }
    int pred = key + 1;
    
    int choise;                  //выбор между шифровкой/расшифровкой
    do
    {
        printf("Input:\n 0. To crypt\n 1. To uncrypt\n 2. To show all 25 optoins\n ");
        choise = get_int();
    }
    while (choise<0 && choise>2);
    //system("clear");
    
    if (choise == 2) 
    {
        key = 0;
        pred = 26;
    }
    
    printf("plaintext: ");
    string text = get_string();
    
    for (; key < pred; key++)
    {
        for (int i=0, l=strlen(text);i<l;i++)
        {
            if (isalpha(text[i]))                     //отбор букв
            {
                if (isupper(text[i]))                 //отбор строчных
                {
                    if (choise==1) text[i]=(text[i]-65+26-key)%26+65; 
                    else text[i]=(text[i]-65+key)%26+65; 
                }
                else  //отбор прописных
                {
                    if (choise==1) text[i]=(text[i]-97+26-key)%26+97;
                    else text[i]=(text[i]-97+key)%26+97; 
                }
            }
        }
        if (choise==0) printf("ciphertext: %s\n",text);
        else printf("plaintext (key = %i): %s\n",key,text);
    }
    return 0;
}
