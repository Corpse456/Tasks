#include <cs50.h>

typedef struct
{
    string name;
    string dorm;
}
student;
