#include <cs50.h>
#include <stdio.h>

int main(void)
{
    system("clear");
    int s,x,y;
    
do
{
    printf("Height of the pyramid (<24): ");
    s = get_int();
}
while (s<0||s>=24);

    y=s;
    
    for (int n=1; n<=s; n++)
    {
        for (x=y; x>1; x--)
        {
            printf(" ");
        }
        for (int i=0 ; i<n; i++)
        {
            printf("#");
        }
        
        printf("  ");
        
        
        for (int i=n ; i>0; i--)
        {    
            printf("#");
        }
        printf("\n");
        y--;
    }
return 0;
}