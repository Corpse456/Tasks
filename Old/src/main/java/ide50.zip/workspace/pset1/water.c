#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("How many minutes you are staying  in shower? ");
    unsigned int s = get_int();
    printf("Бутылок ископаемой питьевой воды вылито в канализацию: %i\n",s*12);
return 0;
}