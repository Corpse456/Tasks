#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h> 
int main(void)
{
    double answer = 0;
    for (int n=1, x=62; n<5; n++)
    {
    answer = answer + pow(x,n);
    printf("%.0f\n",answer);
    }
    printf("hello, world\n");
    
    srand(time(NULL));
    for (int i = 0; i < 10; i++)
    {
        printf("%i \n",-rand()%2);
    }
}