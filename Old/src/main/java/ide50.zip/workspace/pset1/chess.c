//#include <cs50.h>
#include <stdio.h>

void Letter(); //вывод букв
void Cell(int); //вывод клеток

int main(void)
{
    //system("clear");
    
    Letter();
    
    for (int j = 1; j < 9; j++) 
    {
        printf("\n\t\t    ");
        Cell(j);
        printf("\n\t\t%i   ",j); //цифры слева
        Cell(j);
        printf("   %i\n\t\t    ",j); //цифры справа
        Cell(j);
    }
    
    Letter();
    
    return 0;
}

void Letter()
{
    printf("\n\n");
    printf("\t\t\t");
    for (int i = 'A'; i <= 'H'; i++)
    {
        printf("%c\t",i);
    }
    printf("\n");
}

void Cell(int black)
{
    if (black%2 == 1)
    {
        for (int k = 0; k < 4 ; k++)
        {
            printf("||||||||        ");
        }
    }
    else
    {
        for (int k = 0; k < 4 ; k++)
        {
            printf("        ||||||||");
        }
    }
}