//Программа подсчёта сдачи
#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    system("clear");
    int i,x;
    float c;

    printf("O hai! How much change is owed?\n");
    c = get_float();

while (c<=0||c>10000000)
{
    printf("Incorrect input, please try again\n");
    c = get_float();
}
    c = round(c*100);
    printf("%f\n",c);
    i = (int)c;
    if (i%25==0) 
        printf("%i\n", i/25);
    else 
    {
        x=i/25;
        i%=25;
        if (i%10==0) printf("%i\n", x+i/10);
        else 
        {
            x+=i/10;
            i%=10;
            if (i%5==0) printf("%i\n", x+i/5);
            else printf("%i\n", x+i/5+i%5/1);
        }
    }
return 0;
}